
package frame_primerospasos;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

/**
 *
 * @author Leandro
 */
public class class_Pelota {
    //Atributos
    private static final int TAMX=15;
    private static final int TAMY=15;
    //Coordenada de la pelota
    private double x=0;
    private double y=0;
    
    //Coordenadas que ira tomando la pelota
    
    private double dx=1;
    private double dy=1;
    
    public Ellipse2D getForma(){
        
        return new Ellipse2D.Double(x,y,TAMX,TAMY);
              
    }
    
    public void mueve_Pelota(Rectangle2D limites){
        //Con ello logramos el movimiento
        
        x +=dx;
        y +=dy;
        //Calculos para el eje Y
        if(x<limites.getMinX()){
            x=limites.getMinX();
            dx=-dx;
        }
        if(x + TAMX>=limites.getMaxX()){
            x=limites.getMaxX() - TAMX;
            dx=-dx;
        }
        
        //Calculos para el eje X
        if(y<limites.getMinX()){
            y=limites.getMinY();
            dy=-dy;
        }
        if(y+ TAMY>=limites.getMaxY()){
            y=limites.getMaxY() -TAMY;
            dy=-dy;
        }
    }   
}
