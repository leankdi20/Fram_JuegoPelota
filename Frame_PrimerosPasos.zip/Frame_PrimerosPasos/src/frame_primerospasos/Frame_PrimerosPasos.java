
package frame_primerospasos;

import javax.swing.JFrame;

/**
 *
 * @author Leandro
 */
public class Frame_PrimerosPasos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //TODO code application logic here
        JFrame obj = new class_MarcoRebote();
        //Metodo para hacer visible
        
        obj.setVisible(true);
        
        //Metdo donde especifique que debe hacer el programa al cerrar la ventana
        obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
