
package frame_primerospasos;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import javax.swing.JPanel;
/**
 *
 * @author Leandro
 */
public class class_PanelPelota extends JPanel{ 
    
    //Arreglo para poder agrear varias pelotas
    private ArrayList<class_Pelota> pelotas = new ArrayList<class_Pelota>();
    
    //Añadimos pelota a la lamina
    public void add(class_Pelota b){
        //Agregamos la pelota al panel
        pelotas.add(b);
    }
    //Metodo para dibujar la pelota en el panel
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2=(Graphics2D)g;
        for(class_Pelota b: pelotas){
            g2.fill(b.getForma());
        }
    }
}
