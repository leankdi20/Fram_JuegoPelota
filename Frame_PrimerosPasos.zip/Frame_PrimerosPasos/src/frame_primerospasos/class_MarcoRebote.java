package frame_primerospasos;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Leandro
 */
public class class_MarcoRebote extends JFrame {

    private class_PanelPelota panel;
    Thread bola ;// Saqué este atributo del metodo comienza juego
    Thread  bola2, bola3;
    JButton inicio1, inicio2, inicio3;
    JButton detiene1, detiene2, detiene3;
    JButton salir; 
    //Ponemos botones
    /*public void ponerBoton(Container c, String titulo, ActionListener oyente) {

        JButton boton = new JButton(titulo);
        c.add(boton);
        boton.addActionListener(oyente);

    }*/
    //Constructor
   

    public class_MarcoRebote() {
        setBounds(300, 150, 700, 400);
        setTitle("Rebotes");

        panel = new class_PanelPelota();
        //Agregamos el panel de pelota al marco
        add(panel, BorderLayout.CENTER);

        JPanel panel_Botones = new JPanel();
        
          // --------------------------------------------- Creamos botón Inicio 1
        inicio1 = new JButton("Hilo_1");
        inicio1.addActionListener(
                                    new ActionListener()
                                    {
                                        public void actionPerformed(ActionEvent evento)
                                        {
                                            comienza_el_juego(evento);
                                        }
                                    }
                                  );
        panel_Botones.add(inicio1);
         // --------------------------------------------- Creamos botón Inicio 2
        inicio2 = new JButton("Hilo_2");
        inicio2.addActionListener(
                                    new ActionListener()
                                    {
                                        public void actionPerformed(ActionEvent evento)
                                        {
                                            comienza_el_juego(evento);
                                        }
                                    }
                                  );
        panel_Botones.add(inicio2);
        // --------------------------------------------- Creamos botón Inicio 3
        inicio3 = new JButton("Hilo_3");
        inicio3.addActionListener(
                                    new ActionListener()
                                    {
                                        public void actionPerformed(ActionEvent evento)
                                        {
                                            comienza_el_juego(evento);
                                        }
                                    }
                                  );
        panel_Botones.add(inicio3);
          // -------------------------------------------- Creamos botón Detener 1
        detiene1 = new JButton("Detener_1");
        detiene1.addActionListener(
                                    new ActionListener()
                                    {
                                        public void actionPerformed(ActionEvent evento)
                                        {
                                            detenerPelota(evento);
                                        }
                                    }
                                  );
        //detiene1.setEnabled(false);
        panel_Botones.add(detiene1);
         // -------------------------------------------- Creamos botón Detener 2
        detiene2 = new JButton("Detener_2");
        detiene2.addActionListener(
                                    new ActionListener()
                                    {
                                        public void actionPerformed(ActionEvent evento)
                                        {
                                            detenerPelota(evento);
                                        }
                                    }
                                  );
        panel_Botones.add(detiene2);
         // -------------------------------------------- Creamos botón Detener 3
        detiene3 = new JButton("Detener_3");
        detiene3.addActionListener(
                                    new ActionListener()
                                    {
                                        public void actionPerformed(ActionEvent evento)
                                        {
                                            detenerPelota(evento);
                                        }
                                    }
                                  );
        panel_Botones.add(detiene3);
         // ----------------------------------------------- Creamos botón Salir
        salir = new JButton("Salir");
        salir.addActionListener(
                                    new ActionListener()
                                    {
                                        public void actionPerformed(ActionEvent evento)
                                        {
                                            System.exit(0);
                                        }
                                    }
                                  );
        panel_Botones.add(salir);
        // Agremamos el panel de botones al marco	
        add(panel_Botones, BorderLayout.SOUTH);
       

       /* ponerBoton(panel_Botones, "Iniciar", new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                comienza_el_juego();
            }
        });
        
        ponerBoton(panel_Botones, "Detener", new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                detenerPelota();
            }
        });
        

        ponerBoton(panel_Botones, "Salir", new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                System.exit(0);
            }
        });
        */
       
       
       

        //Agregamos el panel de botones al marco
       // add(panel_Botones, BorderLayout.SOUTH);

    }

    //Añade pelota
    public void comienza_el_juego(ActionEvent e)
    {
        class_Pelota pelota = new class_Pelota();
        panel.add(pelota);
        
         // Instancia de la que implementa Runnable (class_PelotaHilos)
       
        Runnable runna = new class_PelotaHilos(pelota, panel);
        
        
        if(e.getSource().equals(inicio1))
        {                   
        //Instancia de objeto
        bola = new Thread (runna);// Es la instancia del atributo .        
        bola.start();
        inicio1.setEnabled(false);
        JOptionPane.showMessageDialog(null,
                "Se deshabilita boton Inicio_1 hasta que se detenga el hilo ");
        detiene1.setEnabled(true);
        }
          else if ( e.getSource().equals(inicio2) )
        {
            bola2 = new Thread (runna);
            bola2.start();
        }
        else if ( e.getSource().equals(inicio3) )
        {
            bola3 = new Thread (runna);
            bola3.start();
        }
       
        /*for (int i = 1; i <= 1000; i++)
        {
            pelota.mueve_Pelota(panel.getBounds());
            panel.paint(panel.getGraphics());
            try
            {
                Thread.sleep(4);
            } catch (InterruptedException e)
            {
                System.out.println("Error en el hilo 1 " + e);
            }*/

        }
     // Metodo para detener hilos 
    public void detenerPelota(ActionEvent e)
    {
        if(e.getSource().equals(detiene1))
        {//bola.stop();
            bola.interrupt();
            inicio1.setEnabled(true);
            detiene1.setEnabled(false);
        }
        else if ( e.getSource().equals(detiene2) )
        {
            bola2.interrupt();
        }
        else if ( e.getSource().equals(detiene3) )
        {
            bola3.interrupt();
        }
    }
  }


