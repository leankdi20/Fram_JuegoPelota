package frame_primerospasos;

import java.awt.Component;

/**
 *
 * @author Leandro
 */
public class class_PelotaHilos implements Runnable {
    //Atributos

    private class_Pelota pelota;

    //Clase abstracta que representa todo lo que tiene una posicion,
    // un tamaño, puede ser pintado en la pantalla y puede recibir eventos.
    private Component componente;//import java.awt.Component;

    //Constructor
    public class_PelotaHilos(class_Pelota unapelota, Component objComponente) {
        this.pelota = unapelota;
        this.componente = objComponente;
    }

    //Metodo abstracto de la interfaz
    @Override
    public void run() {
        //for (int i = 1; i <= 1000; i++)
        while (! Thread.currentThread().isInterrupted())
        {
            pelota.mueve_Pelota(componente.getBounds());
            componente.paint(componente.getGraphics());
            try
            {
                Thread.sleep(4);
            } catch (InterruptedException e)
            {
                //System.out.println("Error en el hilo 1 " + e);
                Thread.currentThread().interrupted();
            }

        }
        System.out.println(" Termina: " + Thread.currentThread().getName() + "estado"
        + Thread.currentThread().isInterrupted() );
    }

}
